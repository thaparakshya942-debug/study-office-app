# Study office dropout-risk model
Ranks first-year students by their risk of leaving later in the first semester, from what the study office
knows at the end of week 6. It supports the advisers' choice of whom to invite for a conversation: **a person decides**.

- Data: synthetic students resampled from the UCI "Predict students' dropout and academic success" data (CC BY 4.0).
- Trained on the 2023-24 cohorts, checked on 2025. AUC 2025: XGBoost 0.783,
  logistic regression 0.809.
- Removed as leakage: ECTS points, deregistration form, last login week (only known after week 6).
- Limits: it reaches about 1 in 5 students who leave with 40 conversations; it reaches international students
  who leave less often, because logins mean something different for them. Patterns, not causes.
- Students must be told the system exists and be able to object.
